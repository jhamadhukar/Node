var fs = require('fs');

exports.addHostEntry = function(req, res) {
		 var hostinfo = req.body;
		 var hostIp = '';
		 var browserParam = '', browserDriverPath = '';
		 var chromePath='', firefoxPath='', commandText='', currentDirectory='';
		 
		 currentDirectory = getCurrentDirectoryName();
		 console.log(currentDirectory);
		 commandText = 'locate "*Firefox.app"';
		execute(commandText);
		 
		 var jarCommandLineArguments='java -jar '+ currentDirectory +'/selenium-server-standalone-2.37.0.jar -role node ';
    console.log('Adding host entry: ' + JSON.stringify(hostinfo));
		
		var stream = fs.createWriteStream("//etc//hosts");
		stream.once('open', function(fd) {
		for(var attributename in hostinfo){
			if(attributename != "HOSTIP" && attributename != "FIREFOX" && attributename != "CHROME")
				stream.write(attributename+": " + hostinfo[attributename]+"\n");
				
			if(attributename == "HostIP")
				hostIp = hostinfo[attributename];
		}

			stream.end();
		});
		
		//console.log(hostinfo["FIREFOX"]);
		
		if(typeof hostinfo["HOSTIP"] != 'undefined'){
			browserParam = " -hub http://"+ hostinfo["HOSTIP"] +":4444/grid/register  ";
			browserDriverPath = '';
		}
		jarCommandLineArguments += browserDriverPath + browserParam;
            browserDriverPath = "";
            browserParam = "";
            
        if(typeof hostinfo["CHROME"] != 'undefined'){
			browserParam = " -browser \""+ hostinfo["CHROME"] +"\" ";
			browserDriverPath = " -Dwebdriver.chrome.driver=\""+ currentDirectory +"/chromedriver\" ";
		}
		jarCommandLineArguments += browserDriverPath + browserParam;
            browserDriverPath = "";
            browserParam = "";
            
		if(typeof hostinfo["FIREFOX"] != 'undefined'){
			browserParam = " -browser \""+ hostinfo["FIREFOX"] +"\" ";
			browserDriverPath = " -Dwebdriver.firefox.driver="+ firefoxPath +" ";
		}
		jarCommandLineArguments += browserDriverPath + browserParam;
            browserDriverPath = "";
            browserParam = "";
            
		
		commandText = 'locate "*Chrome.app"';
		execute(commandText);
		
		
		
		commandText = jarCommandLineArguments;//'java -jar '+ currentDirectory +'/selenium-server-standalone-2.37.0.jar -role node -Dwebdriver.chrome.driver="'+ currentDirectory +'/chromedriver" -Dwebdriver.firefox.driver="'+ firefoxPath +'"  -hub http://'+ hostIp +':4444/grid/register -browser "browserName=chrome,maxInstance=1"';
		console.log(commandText);
		execute(commandText);
		
		
		res.send("Successful");
};

//function run_cmd(cmd, args, callBack ) {
    var exec = require('child_process').exec;
function execute(command){
    exec(command, function(error, stdout, stderr){ });
};
   
    //var spawn = require('child_process').spawn;
    //var child = spawn(cmd, args);
    //var resp = "";

    //child.stdout.on('data', function (buffer) { resp += buffer.toString() });
    //child.stdout.on('end', function() { callBack (resp) });
//}
function getCurrentDirectoryName() { 
	var fullPath = __dirname; 
	//console.log(fullPath);
	//var path = fullPath.split('/'); 
	//var cwd = path[path.length-1]; 
	return fullPath; 
}
