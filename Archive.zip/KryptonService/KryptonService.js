var webservice = require('Modules/webservice'),
    demoModule = require('Modules/Service');

webservice.createServer(demoModule).listen(8080);
console.log(' > json webservice started on port 8080');  