var IpAddress='';
var netService = require('net').createServer(function(socket) {
 address = netService.address();
 console.log("Stream on %j", socket.address());
 console.log("opened server on %j", IpAddress);
});
require('dns').lookup(require('os').hostname(), function (err, add, fam) {
  IpAddress = add;
  console.log("Listening on "+ IpAddress +" on port 8001...");
})
netService.listen(8001);