var fs = require('fs');
exports.findAll = function(req, res) {
    res.send([{name:'wine1'}, {name:'wine2'}, {name:'wine3'}]);
};
 
exports.findById = function(req, res) {
	

    res.send({id:req.params.id, name: "The Name", description: "description"});
};

exports.addWine = function(req, res) {
		//var wine = req.body;
		//console.log(hostinfo);
		 var wine = req.body;
    console.log('Adding wine: ' + JSON.stringify(wine));
		
		fs.writeFile("C:\\Windows\\System32\\drivers\\etc\\hosts", JSON.stringify(wine), function(err) {
		if(err) {
			console.log(err);
		} else {
				console.log("The file was saved!");
		}
		}); 
		
		res.send("got it");
		
		
		//var stream = fs.createWriteStream("C:\\Windows\\System32\\drivers\\etc\\hosts");
		//stream.once('open', function(fd) {
		//  stream.write(req.body);
		 
		//  stream.end();
		//});
		
		
    //var wine = req.body;
    //console.log('Adding wine: ' + JSON.stringify(wine));
    //db.collection('wines', function(err, collection) {
    //    collection.insert(wine, {safe:true}, function(err, result) {
    //        if (err) {
    //            res.send({'error':'An error has occurred'});
    //        } else {
    //            console.log('Success: ' + JSON.stringify(result[0]));
    //            res.send(result[0]);
    //        }
    //    });
    //});
};
 