//var express = require('express'),
//modules = require('./routes/modules');
 
//var app = express();
// app.configure(function () {
//    app.use(express.logger('dev'));     /* 'default', 'short', 'tiny', 'dev' */
//    //app.use(express.bodyParser());
//});

//app.post('/KryptonGridService/ConfigureHostFile', modules.addHostEntry);
 
//app.listen(8001);
//console.log('Listening on port 8001...');

var http = require('http');
var url = require('url');
var modules = require('./routes/modules');


var server = http.createServer(function(req, res){
	switch (req.method) {
		case 'POST':
			console.log(req.url);
			if(req.url == '/KryptonGridService/ConfigureHostFile'){
				var items = [];
				var item = '';
				req.setEncoding('utf8');
				req.on('data', function(chunk){
					item += chunk;
				});
				req.on('end', function(){
					items.push(item);
					modules.addHostEntry(items);
					
					req.removeListener('data', function(){});
					req.removeListener('end', function(){});
				});
			
				res.end("Successfully updated");
			}
			
			if(req.url == '/KryptonGridService/InitializeSeleniumDriver'){
				
				var items = [];
				var item = '';
				req.setEncoding('utf8');
				req.on('data', function(chunk){
					item += chunk;
				});
				req.on('end', function(){
				
					items.push(item);
					modules.InitializeSeleniumDriver(items);
					req.removeListener('data', function(){});
					req.removeListener('end', function(){});
				});			
				res.end("\n");
			}
			
			if(req.url == '/KryptonGridService/RestoreHostFile'){
				//console.log('Inside server.js');
				req.setEncoding('utf8');
				req.on('end', function(){
					modules.RestoreHostFile();
					req.removeListener('end', function(){});
				});			
				res.end("Successfully restored\n");
			}
			break;	
					
	}
});
server.listen(8001);
console.log('Listening on port 8001...');