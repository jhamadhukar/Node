var fs = require('fs');
var parseString = require('xml2js').parseString;

exports.InitializeSeleniumDriver = function(req){
		console.log(req);
		var hostinfo = req;
		var browser ='', browserInfo ='', hostIp ='';
			 var browserParam = '', browserDriverPath = '';
		 var chromePath='', firefoxPath='', commandText='', currentDirectory='';
		
		
		parseString(hostinfo, function (err, result) {
    		browser = (result.IntializeSeleniumGridDriveRequestData.browser)[0];
    		browserInfo = (result.IntializeSeleniumGridDriveRequestData.browserInfo)[0];
    		hostIp = (result.IntializeSeleniumGridDriveRequestData.hostIp)[0];
		});	
		console.log("Browser: " + hostIp + " BrowserInfo: " + 
							browserInfo + " HostIp: " + hostIp);


		 currentDirectory = getCurrentDirectoryName(); 
		 console.log(currentDirectory);
		 commandText = 'locate "*Firefox.app"';
		 execute(commandText, function(output){firefoxPath = output;});
		 
		 var jarCommandLineArguments='java -jar '+ currentDirectory +'/selenium-server-standalone-2.37.0.jar  -role node -port 8002 ';
    			

		if(hostIp != ''){
			browserParam = " -hub http://"+ hostIp +":4444/grid/register  ";
			browserDriverPath = '';
		}
		jarCommandLineArguments += browserDriverPath + browserParam;
            browserDriverPath = "";
            browserParam = "";
            
        if(browser != '' && browserInfo != ''){
        	if(browser.toLowerCase() == 'chrome'){
        		browserParam =  " -browser \"browserName="+ browser +", "+ browserInfo +"\" ";
				browserDriverPath = " -Dwebdriver.chrome.driver=\""+ currentDirectory +"/chromedriver\" ";
        	}
        	jarCommandLineArguments += browserDriverPath + browserParam;
            browserDriverPath = "";
            browserParam = "";
            
            
            if(browser.toLowerCase() == 'firefox'){
        		browserParam =  " -browser \"browserName="+ browser +", "+ browserInfo +"\" ";
				browserDriverPath = " -Dwebdriver.firefox.driver=\""+ firefoxPath +"\" ";
        	}
        	jarCommandLineArguments += browserDriverPath + browserParam;
            browserDriverPath = "";
            browserParam = "";
        }
        		
		commandText = jarCommandLineArguments;//'java -jar '+ currentDirectory +'/selenium-server-standalone-2.37.0.jar -role node -Dwebdriver.chrome.driver="'+ currentDirectory +'/chromedriver" -Dwebdriver.firefox.driver="'+ firefoxPath +'"  -hub http://'+ hostIp +':4444/grid/register -browser "browserName=chrome,maxInstance=1"';
		console.log(commandText);
		execute(commandText);
		return "Successful";
		
};

exports.addHostEntry = function(req) {
		var hostinfo = req;
		currentDirectory = getCurrentDirectoryName(); 
		copyFile('//etc/hosts', currentDirectory + '/hosts', function(err){console.log(err)});
		parseString(hostinfo, function (err, result) {
    		hostinfo = result.RequestData.details;
		});	
		console.log(hostinfo[0]);
		var stream = fs.createWriteStream("//etc/hosts");
		stream.once('open', function(fd) {
		    stream.write(hostinfo[0]);
			stream.end();	
		});
		
		return "Successful";
};

exports.RestoreHostFile = function(){
	//console.log('Inside restore file');
	currentDirectory = getCurrentDirectoryName(); 
	copyFile(currentDirectory +'/hosts', '//etc/hosts', function(err){console.log('Host file restored')});
	return "Successful";
};

function copyFile(source, target, cb) {
  var cbCalled = false;

  var rd = fs.createReadStream(source);
  rd.on("error", function(err) {
    done(err);
  });
  var wr = fs.createWriteStream(target);
  wr.on("error", function(err) {
    done(err);
  });
  wr.on("close", function(ex) {
    done();
  });
  rd.pipe(wr);

  function done(err) {
    if (!cbCalled) {
      cb(err);
      cbCalled = true;
    }
  }
}


//function run_cmd(cmd, args, callBack ) {
    var exec = require('child_process').exec;
function execute(command, callback){
    exec(command, function(error, stdout, stderr){ callback(stdout); });
};
   
    //var spawn = require('child_process').spawn;
    //var child = spawn(cmd, args);
    //var resp = "";

    //child.stdout.on('data', function (buffer) { resp += buffer.toString() });
    //child.stdout.on('end', function() { callBack (resp) });
//}
function getCurrentDirectoryName() { 
	var fullPath = __dirname; 
	//console.log(fullPath);
	//var path = fullPath.split('/'); 
	//var cwd = path[path.length-1]; 
	return fullPath; 
};
